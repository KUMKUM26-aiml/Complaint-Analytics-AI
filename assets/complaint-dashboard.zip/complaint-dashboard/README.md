# Unified Customer Complaint Dashboard
### iDEA 2.0 Hackathon — PS05 | Union Bank of India | Gen-AI Powered

---

## What this app does

- Ingests complaints from 6 channels (branch, phone, email, app, social, RBI portal)
- Uses Claude AI to auto-classify by category, severity, product, and sentiment
- Detects duplicate complaints using semantic similarity (works across Hindi + English)
- Generates AI draft responses for agent review
- Tracks SLA deadlines with auto-escalation
- Analytics dashboard with AI-powered trend summaries and root cause analysis

---

## Prerequisites — install these first

| Tool | Download | Check |
|------|----------|-------|
| Python 3.11+ | https://python.org | `python --version` |
| Node.js 20+ | https://nodejs.org | `node --version` |
| Docker Desktop | https://docker.com | Open Docker app |
| VS Code | https://code.visualstudio.com | — |

---

## Step-by-step setup

### Step 1 — Open in VS Code

```bash
# In your terminal, navigate to where you downloaded/unzipped this project
cd complaint-dashboard

# Open VS Code in this folder
code .
```

### Step 2 — Add your API key

Copy the example env file and add your Anthropic API key:

```bash
cd backend
cp .env.example .env
```

Open `backend/.env` in VS Code and replace `sk-ant-YOUR_KEY_HERE` with your real key.
Get a key at: https://console.anthropic.com → API Keys → Create Key

**Note:** The app works without an API key (returns mock AI responses), so you can test the full flow first.

### Step 3 — Start the database (Docker)

Make sure Docker Desktop is running, then in VS Code terminal:

```bash
# From the project root (complaint-dashboard/)
docker-compose up -d
```

Wait 10 seconds for PostgreSQL to be ready. Check with:
```bash
docker ps
# Should show complaint-dashboard-db-1 and complaint-dashboard-redis-1 running
```

### Step 4 — Set up the Python backend

Open a terminal in VS Code (Ctrl+`) and run:

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install dependencies (takes 3-5 minutes)
pip install -r requirements.txt

# Start the API
uvicorn main:app --reload --port 8000
```

You should see:
```
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     Application startup complete.
```

Open http://localhost:8000/docs to see the interactive API documentation.

### Step 5 — Set up the React frontend

Open a **new terminal tab** in VS Code (click the + icon in the terminal panel):

```bash
cd frontend

# Install dependencies
npm install

# Start the frontend
npm run dev
```

You should see:
```
  VITE v5.x  ready in XXX ms
  ➜  Local:   http://localhost:3000/
```

Open http://localhost:3000 in your browser.

### Step 6 — Load demo data (optional but recommended)

Open a **third terminal tab**:

```bash
cd backend
source venv/bin/activate  # or venv\Scripts\activate on Windows

python seed_demo.py
```

This submits 8 realistic complaints including:
- A Hindi UPI complaint and an English UPI complaint (AI detects as duplicates)
- A fraud report (triggers critical severity + 2-hour SLA)
- A loan disbursement complaint (triggers escalation)

---

## How to use the app

### Dashboard page
- **Left panel**: complaint list with search and filters
- **Right panel**: click any complaint to see full details
- **+ New Complaint**: submit a complaint (any language, any channel)
- **Refresh SLA**: recalculate SLA status for all open complaints

### Analytics page
- Charts showing complaints by category, severity, and channel
- **Generate Summary**: AI writes a weekly trend analysis
- **Root Cause Analysis**: select a category → AI analyses patterns

---

## VS Code terminal layout (keep all 3 running)

```
Terminal 1 (Docker):   docker-compose up -d
Terminal 2 (Backend):  cd backend && uvicorn main:app --reload --port 8000
Terminal 3 (Frontend): cd frontend && npm run dev
```

---

## Project structure

```
complaint-dashboard/
├── backend/
│   ├── app/
│   │   ├── main.py              ← FastAPI app entry point
│   │   ├── models.py            ← Database tables (SQLAlchemy)
│   │   ├── schemas.py           ← Request/response shapes (Pydantic)
│   │   ├── database.py          ← DB connection
│   │   ├── routers/
│   │   │   ├── complaints.py    ← POST/GET/PATCH complaint endpoints
│   │   │   └── analytics.py     ← Trends + AI summary endpoints
│   │   └── services/
│   │       ├── nlp_service.py   ← Claude AI classification + response gen
│   │       ├── sla_service.py   ← SLA deadline computation
│   │       └── dedup_service.py ← Semantic duplicate detection
│   ├── main.py                  ← Uvicorn entry point
│   ├── seed_demo.py             ← Demo data loader
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   └── src/
│       ├── App.jsx              ← Navigation + layout
│       ├── pages/
│       │   ├── DashboardPage.jsx ← Main complaint view
│       │   └── AnalyticsPage.jsx ← Charts + AI insights
│       ├── components/
│       │   ├── DetailPanel.jsx  ← Complaint detail + response editor
│       │   ├── SubmitModal.jsx  ← New complaint form
│       │   └── Badge.jsx        ← Reusable badge component
│       ├── api/complaints.js    ← API client
│       └── utils.js             ← Constants + helpers
└── docker-compose.yml           ← PostgreSQL + Redis
```

---

## API endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /complaints/ | Submit complaint → AI processes it |
| GET | /complaints/ | List with filters |
| GET | /complaints/{id} | Single complaint with history |
| PATCH | /complaints/{id} | Update status / assign |
| POST | /complaints/{id}/send-response | Agent sends response |
| POST | /complaints/refresh-sla | Recalculate SLA statuses |
| GET | /analytics/trends | Complaint counts and distributions |
| GET | /analytics/ai-summary | AI-written trend summary |
| GET | /analytics/root-cause/{category} | AI root cause analysis |

Full interactive docs: http://localhost:8000/docs

---

## Stopping the app

```bash
# Stop frontend: Ctrl+C in Terminal 3
# Stop backend: Ctrl+C in Terminal 2
# Stop Docker:
docker-compose down
```

To wipe the database and start fresh:
```bash
docker-compose down -v
docker-compose up -d
```
