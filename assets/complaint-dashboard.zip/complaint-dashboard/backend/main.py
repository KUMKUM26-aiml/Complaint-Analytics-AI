from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import engine
from app import models
from app.routers import complaints, analytics

# Create all database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Unified Complaint Dashboard API",
    description="Gen-AI powered complaint management for Union Bank of India",
    version="1.0.0"
)

# CORS - allow React frontend to talk to this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(complaints.router)
app.include_router(analytics.router)


@app.get("/")
def root():
    return {
        "status": "running",
        "message": "Unified Complaint Dashboard API",
        "docs": "/docs"
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
