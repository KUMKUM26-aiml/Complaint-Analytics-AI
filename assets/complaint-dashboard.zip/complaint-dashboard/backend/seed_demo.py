"""
Run this after starting the backend to populate the dashboard with demo data.
Usage: python seed_demo.py
"""
import httpx
import asyncio
import time

BASE_URL = "http://localhost:8000"

DEMO_COMPLAINTS = [
    {
        "customer_id": "CUST-SHARMA-001",
        "channel": "app",
        "raw_text": "Mera UPI payment fail ho gaya lekin mere account se 500 rupaye kat gaye. Ye 3rd time ho raha hai is mahine. Bahut pareshaan hoon. Please jaldi refund karo."
    },
    {
        "customer_id": "CUST-PATEL-002",
        "channel": "email",
        "raw_text": "My UPI transaction failed but money was deducted from my account. Reference number TXN928472. This is the third time this month. Please refund immediately."
    },
    {
        "customer_id": "CUST-MENON-003",
        "channel": "social",
        "raw_text": "URGENT: Home loan was sanctioned 3 months ago but still not disbursed. I have possession date next week and the builder is threatening to cancel. This is completely unacceptable from a nationalized bank. Escalating to RBI if not resolved in 24 hours."
    },
    {
        "customer_id": "CUST-VERMA-004",
        "channel": "branch",
        "raw_text": "Internet banking has not been working since yesterday. I keep getting error code 504 every time I try to login. I need to make urgent payments for my business."
    },
    {
        "customer_id": "CUST-REDDY-005",
        "channel": "phone",
        "raw_text": "I suspect fraudulent transactions on my account. Two transactions of Rs 15,000 each that I did not authorize. Please block my card immediately and reverse these transactions."
    },
    {
        "customer_id": "CUST-IYER-006",
        "channel": "app",
        "raw_text": "My fixed deposit matured last week but the amount has not been credited to my savings account. FD number FD-2024-8821. The maturity amount was Rs 1,25,000."
    },
    {
        "customer_id": "CUST-GUPTA-007",
        "channel": "email",
        "raw_text": "UPI payment of Rs 2000 failed but money got deducted from my bank account. Please help me get a refund. Transaction ID: UPI8823991."
    },
    {
        "customer_id": "CUST-SINGH-008",
        "channel": "social",
        "raw_text": "Debit card is blocked without any notice. I was traveling and suddenly card stopped working at ATM. Very embarrassing situation. Please unblock immediately."
    },
]


async def seed():
    print("Starting demo data seeding...")
    print(f"Connecting to {BASE_URL}\n")

    async with httpx.AsyncClient(timeout=30.0) as client:
        # Check API is running
        try:
            r = await client.get(f"{BASE_URL}/health")
            print(f"API Status: {r.json()['status']}\n")
        except Exception as e:
            print(f"ERROR: Cannot connect to API at {BASE_URL}")
            print(f"Make sure the backend is running: uvicorn main:app --reload")
            print(f"Error: {e}")
            return

        for i, complaint in enumerate(DEMO_COMPLAINTS, 1):
            print(f"[{i}/{len(DEMO_COMPLAINTS)}] Submitting complaint for {complaint['customer_id']}...")
            try:
                r = await client.post(f"{BASE_URL}/complaints/", json=complaint)
                data = r.json()
                print(f"  ID: {data['id'][:8]}...")
                print(f"  Category: {data.get('category', 'N/A')}")
                print(f"  Severity: {data.get('severity', 'N/A')}")
                print(f"  Sentiment: {data.get('sentiment_label', 'N/A')} ({data.get('sentiment_score', 0):.2f})")
                if data.get('duplicate_of'):
                    print(f"  *** DUPLICATE DETECTED of complaint {data['duplicate_of'][:8]}!")
                print()
            except Exception as e:
                print(f"  Error: {e}\n")
            
            # Small delay to avoid rate limiting
            await asyncio.sleep(0.5)

    print("Seeding complete! Open http://localhost:3000 to view the dashboard.")


if __name__ == "__main__":
    asyncio.run(seed())
