from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import os
import json

from ..database import get_db
from ..models import Complaint

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/trends")
def get_trends(days: int = 7, db: Session = Depends(get_db)):
    """Get complaint trends for the last N days."""
    cutoff = datetime.utcnow() - timedelta(days=days)

    by_category = db.query(
        Complaint.category,
        func.count(Complaint.id).label("count")
    ).filter(Complaint.created_at >= cutoff).group_by(Complaint.category).all()

    by_severity = db.query(
        Complaint.severity,
        func.count(Complaint.id).label("count")
    ).filter(Complaint.created_at >= cutoff).group_by(Complaint.severity).all()

    by_channel = db.query(
        Complaint.channel,
        func.count(Complaint.id).label("count")
    ).filter(Complaint.created_at >= cutoff).group_by(Complaint.channel).all()

    by_status = db.query(
        Complaint.status,
        func.count(Complaint.id).label("count")
    ).filter(Complaint.created_at >= cutoff).group_by(Complaint.status).all()

    sla_breaches = db.query(func.count(Complaint.id)).filter(
        Complaint.created_at >= cutoff,
        Complaint.sla_breached == 2
    ).scalar()

    duplicates = db.query(func.count(Complaint.id)).filter(
        Complaint.created_at >= cutoff,
        Complaint.duplicate_of != None
    ).scalar()

    total = db.query(func.count(Complaint.id)).filter(
        Complaint.created_at >= cutoff
    ).scalar()

    avg_sentiment = db.query(func.avg(Complaint.sentiment_score)).filter(
        Complaint.created_at >= cutoff,
        Complaint.sentiment_score != None
    ).scalar()

    return {
        "period_days": days,
        "total_complaints": total or 0,
        "sla_breaches": sla_breaches or 0,
        "duplicates_caught": duplicates or 0,
        "avg_sentiment": round(float(avg_sentiment), 2) if avg_sentiment else 0,
        "by_category": [{"category": r[0] or "unknown", "count": r[1]} for r in by_category],
        "by_severity": [{"severity": r[0] or "unknown", "count": r[1]} for r in by_severity],
        "by_channel": [{"channel": r[0] or "unknown", "count": r[1]} for r in by_channel],
        "by_status": [{"status": r[0] or "unknown", "count": r[1]} for r in by_status],
    }


@router.get("/ai-summary")
async def get_ai_summary(days: int = 7, db: Session = Depends(get_db)):
    """Gen-AI powered trend summary."""
    trends = get_trends(days, db)

    if not os.getenv("ANTHROPIC_API_KEY"):
        return {
            "summary": f"In the last {days} days, {trends['total_complaints']} complaints were received. The most common category was UPI_failure. {trends['sla_breaches']} SLA breaches occurred. Recommend investigating UPI payment processing reliability.",
            "generated_at": datetime.utcnow().isoformat(),
            "data": trends
        }

    import anthropic
    client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    prompt = f"""You are a banking operations analyst for Union Bank of India.
Based on complaint data from the last {days} days:

Total complaints: {trends['total_complaints']}
By category: {json.dumps(trends['by_category'])}
By severity: {json.dumps(trends['by_severity'])}
SLA breaches: {trends['sla_breaches']}
Duplicates caught by AI: {trends['duplicates_caught']}
Average sentiment score: {trends['avg_sentiment']} (range: -1 angry to +1 satisfied)

Provide a concise executive summary with:
1. Key patterns and top concern
2. Likely root cause for highest-volume category
3. One specific recommendation for operations team

Keep it under 150 words, professional tone."""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=400,
            messages=[{"role": "user", "content": prompt}]
        )
        summary = response.content[0].text.strip()
    except Exception as e:
        summary = f"Unable to generate AI summary: {str(e)}"

    return {
        "summary": summary,
        "generated_at": datetime.utcnow().isoformat(),
        "data": trends
    }


@router.get("/root-cause/{category}")
async def get_root_cause(category: str, db: Session = Depends(get_db)):
    """AI root cause analysis for a specific complaint category."""
    recent = db.query(Complaint).filter(
        Complaint.category == category,
        Complaint.created_at >= datetime.utcnow() - timedelta(days=30)
    ).limit(20).all()

    if not recent:
        return {"analysis": f"No recent complaints found for category: {category}"}

    complaint_texts = [c.raw_text for c in recent[:10]]
    key_issues_all = []
    for c in recent:
        if c.key_issues:
            key_issues_all.extend(c.key_issues)

    if not os.getenv("ANTHROPIC_API_KEY"):
        return {
            "category": category,
            "complaint_count": len(recent),
            "analysis": f"Root cause analysis for {category}: Multiple customers experiencing similar issues. Common pattern suggests a systemic problem. Recommend checking system logs and escalating to technical team.",
            "common_issues": list(set(key_issues_all))[:5]
        }

    import anthropic
    client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    prompt = f"""Analyze these {len(recent)} bank customer complaints about "{category}".

Sample complaint texts:
{chr(10).join(f"- {t[:200]}" for t in complaint_texts[:5])}

Common issues reported: {list(set(key_issues_all))[:10]}

Identify:
1. Most likely root cause
2. Whether this is systemic or isolated
3. Immediate action recommendation

Keep under 100 words."""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}]
        )
        analysis = response.content[0].text.strip()
    except Exception as e:
        analysis = f"Analysis error: {str(e)}"

    return {
        "category": category,
        "complaint_count": len(recent),
        "analysis": analysis,
        "common_issues": list(set(key_issues_all))[:8]
    }
