from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import uuid

from ..database import get_db
from ..models import Complaint, Communication
from ..schemas import ComplaintCreate, ComplaintOut, ComplaintUpdate
from ..services.nlp_service import classify_complaint, generate_draft_response, get_embedding
from ..services.dedup_service import find_duplicate
from ..services.sla_service import compute_sla_deadline, check_sla_status

router = APIRouter(prefix="/complaints", tags=["complaints"])


@router.post("/", response_model=ComplaintOut)
async def ingest_complaint(payload: ComplaintCreate, db: Session = Depends(get_db)):
    """Ingest a new complaint and run AI processing pipeline."""

    # 1. Classify with AI
    ai_data = await classify_complaint(payload.raw_text)

    # 2. Generate embedding for deduplication
    embedding = get_embedding(payload.raw_text)

    # 3. Check for duplicates
    duplicate_id = find_duplicate(db, embedding, payload.customer_id)

    # 4. Generate AI draft response
    ai_data["raw_text"] = payload.raw_text
    draft_response = await generate_draft_response(ai_data)

    # 5. Compute SLA deadline
    deadline = compute_sla_deadline(
        ai_data.get("severity", "medium"),
        ai_data.get("category")
    )

    # 6. Create complaint record
    complaint_id = str(uuid.uuid4())
    complaint = Complaint(
        id=complaint_id,
        customer_id=payload.customer_id,
        channel=payload.channel,
        raw_text=payload.raw_text,
        category=ai_data.get("category"),
        product=ai_data.get("product"),
        severity=ai_data.get("severity", "medium"),
        sentiment_score=ai_data.get("sentiment_score"),
        sentiment_label=ai_data.get("sentiment_label"),
        key_issues=ai_data.get("key_issues", []),
        suggested_response=draft_response,
        sla_deadline=deadline,
        duplicate_of=duplicate_id,
        embedding=embedding,
        sla_breached=0
    )
    db.add(complaint)

    # 7. Log initial inbound communication
    comm = Communication(
        id=str(uuid.uuid4()),
        complaint_id=complaint_id,
        channel=payload.channel,
        direction="inbound",
        content=payload.raw_text,
        sent_by="customer"
    )
    db.add(comm)
    db.commit()
    db.refresh(complaint)

    return complaint


@router.get("/", response_model=list[ComplaintOut])
def list_complaints(
    status: str = None,
    severity: str = None,
    category: str = None,
    sla_breached: int = None,
    channel: str = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """List complaints with optional filters."""
    query = db.query(Complaint)

    if status:
        query = query.filter(Complaint.status == status)
    if severity:
        query = query.filter(Complaint.severity == severity)
    if category:
        query = query.filter(Complaint.category == category)
    if sla_breached is not None:
        query = query.filter(Complaint.sla_breached == sla_breached)
    if channel:
        query = query.filter(Complaint.channel == channel)

    return query.order_by(Complaint.created_at.desc()).offset(skip).limit(limit).all()


@router.get("/{complaint_id}", response_model=ComplaintOut)
def get_complaint(complaint_id: str, db: Session = Depends(get_db)):
    """Get a single complaint with full communication history."""
    c = db.query(Complaint).filter(Complaint.id == complaint_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")
    return c


@router.patch("/{complaint_id}", response_model=ComplaintOut)
def update_complaint(complaint_id: str, update: ComplaintUpdate, db: Session = Depends(get_db)):
    """Update complaint status, assignment, etc."""
    c = db.query(Complaint).filter(Complaint.id == complaint_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")

    if update.status:
        c.status = update.status
    if update.assigned_to:
        c.assigned_to = update.assigned_to

    if update.resolution_note and update.status == "resolved":
        comm = Communication(
            id=str(uuid.uuid4()),
            complaint_id=complaint_id,
            channel=c.channel,
            direction="outbound",
            content=update.resolution_note,
            sent_by="agent"
        )
        db.add(comm)

    db.commit()
    db.refresh(c)
    return c


@router.post("/{complaint_id}/send-response")
async def send_response(complaint_id: str, response_text: str, db: Session = Depends(get_db)):
    """Agent sends a response to the customer."""
    c = db.query(Complaint).filter(Complaint.id == complaint_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")

    comm = Communication(
        id=str(uuid.uuid4()),
        complaint_id=complaint_id,
        channel=c.channel,
        direction="outbound",
        content=response_text,
        sent_by="agent"
    )
    db.add(comm)
    c.status = "in_progress"
    db.commit()

    return {"status": "sent", "complaint_id": complaint_id}


@router.post("/refresh-sla")
def refresh_sla_statuses(db: Session = Depends(get_db)):
    """Manually trigger SLA status recalculation for all open complaints."""
    from datetime import datetime

    open_complaints = db.query(Complaint).filter(
        Complaint.status.in_(["open", "in_progress"]),
        Complaint.sla_deadline != None
    ).all()

    updated = 0
    for c in open_complaints:
        new_status = check_sla_status(c.sla_deadline, c.created_at)
        if new_status != c.sla_breached:
            c.sla_breached = new_status
            if new_status == 2 and c.status != "escalated":
                c.status = "escalated"
            updated += 1

    db.commit()
    return {"updated": updated, "total_checked": len(open_complaints)}
