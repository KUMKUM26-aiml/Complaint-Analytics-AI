from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class ComplaintCreate(BaseModel):
    customer_id: str
    channel: str
    raw_text: str


class CommunicationOut(BaseModel):
    id: str
    channel: str
    direction: str
    content: str
    sent_by: str
    created_at: datetime

    class Config:
        from_attributes = True


class ComplaintOut(BaseModel):
    id: str
    customer_id: str
    channel: str
    raw_text: str
    category: Optional[str] = None
    product: Optional[str] = None
    severity: Optional[str] = None
    sentiment_score: Optional[float] = None
    sentiment_label: Optional[str] = None
    key_issues: Optional[List[str]] = None
    suggested_response: Optional[str] = None
    status: str
    assigned_to: Optional[str] = None
    sla_deadline: Optional[datetime] = None
    sla_breached: Optional[int] = 0
    duplicate_of: Optional[str] = None
    created_at: datetime
    communications: Optional[List[CommunicationOut]] = []

    class Config:
        from_attributes = True


class ComplaintUpdate(BaseModel):
    status: Optional[str] = None
    assigned_to: Optional[str] = None
    resolution_note: Optional[str] = None
