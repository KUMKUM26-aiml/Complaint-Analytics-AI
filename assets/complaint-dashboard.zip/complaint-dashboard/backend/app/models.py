from sqlalchemy import Column, String, Integer, Float, DateTime, Enum, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from .database import Base
import enum
import uuid
from datetime import datetime


class ChannelEnum(str, enum.Enum):
    branch = "branch"
    phone = "phone"
    email = "email"
    app = "app"
    social = "social"
    rbi = "rbi"


class SeverityEnum(str, enum.Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class StatusEnum(str, enum.Enum):
    open = "open"
    in_progress = "in_progress"
    escalated = "escalated"
    resolved = "resolved"
    closed = "closed"


class Complaint(Base):
    __tablename__ = "complaints"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    customer_id = Column(String, index=True, nullable=False)
    channel = Column(String, nullable=False)
    raw_text = Column(Text, nullable=False)

    # AI-generated fields
    category = Column(String)
    product = Column(String)
    severity = Column(String, default="medium")
    sentiment_score = Column(Float)
    sentiment_label = Column(String)
    key_issues = Column(JSON)
    suggested_response = Column(Text)

    # Status & SLA
    status = Column(String, default="open")
    assigned_to = Column(String)
    sla_deadline = Column(DateTime)
    sla_breached = Column(Integer, default=0)

    # Deduplication
    duplicate_of = Column(String, ForeignKey("complaints.id"), nullable=True)
    embedding = Column(JSON)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    communications = relationship("Communication", back_populates="complaint")


class Communication(Base):
    __tablename__ = "communications"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    complaint_id = Column(String, ForeignKey("complaints.id"))
    channel = Column(String)
    direction = Column(String)
    content = Column(Text)
    sent_by = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    complaint = relationship("Complaint", back_populates="communications")
