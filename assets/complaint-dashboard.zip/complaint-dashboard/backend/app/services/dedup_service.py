from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from ..services.nlp_service import cosine_similarity

DEDUP_THRESHOLD = 0.82  # tune this - higher = stricter


def find_duplicate(
    db,
    new_embedding: list,
    new_customer_id: str,
    window_hours: int = 72
) -> str | None:
    """
    Search recent open complaints for semantic duplicates.
    Returns complaint_id of the duplicate if found, else None.
    """
    from ..models import Complaint

    cutoff = datetime.utcnow() - timedelta(hours=window_hours)

    candidates = db.query(Complaint).filter(
        Complaint.created_at >= cutoff,
        Complaint.status.in_(["open", "in_progress"]),
        Complaint.duplicate_of == None
    ).all()

    best_score = 0.0
    best_match = None

    for c in candidates:
        if c.embedding is None:
            continue
        try:
            score = cosine_similarity(new_embedding, c.embedding)
            if score > best_score:
                best_score = score
                best_match = c
        except Exception:
            continue

    if best_match and best_score >= DEDUP_THRESHOLD:
        return best_match.id

    return None
