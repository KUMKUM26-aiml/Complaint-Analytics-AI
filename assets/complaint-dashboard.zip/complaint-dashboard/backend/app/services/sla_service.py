from datetime import datetime, timedelta

# SLA rules in hours
SLA_HOURS = {
    "critical": 4,
    "high": 24,
    "medium": 72,
    "low": 168,
}

CATEGORY_SLA_OVERRIDE = {
    "fraud_report": 2,
    "UPI_failure": 24,
    "account_access": 48,
}


def compute_sla_deadline(severity: str, category: str = None) -> datetime:
    """Compute SLA deadline based on severity and category."""
    if category and category in CATEGORY_SLA_OVERRIDE:
        hours = CATEGORY_SLA_OVERRIDE[category]
    else:
        hours = SLA_HOURS.get(severity, 72)
    return datetime.utcnow() + timedelta(hours=hours)


def check_sla_status(deadline: datetime, created_at: datetime) -> int:
    """
    Returns:
        0 = on time
        1 = warning (less than 20% time remaining)
        2 = breached
    """
    now = datetime.utcnow()
    if now >= deadline:
        return 2

    total_seconds = (deadline - created_at).total_seconds()
    remaining_seconds = (deadline - now).total_seconds()

    if total_seconds <= 0:
        return 2

    if remaining_seconds / total_seconds < 0.20:
        return 1

    return 0
