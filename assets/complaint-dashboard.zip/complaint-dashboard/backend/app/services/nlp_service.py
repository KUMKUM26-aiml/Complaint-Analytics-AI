import anthropic
import json
import os
import numpy as np
from dotenv import load_dotenv

load_dotenv()

# Try to import sentence_transformers, fall back to simple embedding if not available
try:
    from sentence_transformers import SentenceTransformer
    embedder = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")
    USE_TRANSFORMER = True
except Exception:
    USE_TRANSFORMER = False
    print("sentence-transformers not available, using simple embeddings")

client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY", ""))

CLASSIFICATION_PROMPT = """You are a banking complaint classifier for an Indian public sector bank (Union Bank of India).
Analyze the complaint and return ONLY a valid JSON object with exactly these keys:

{{
  "category": "one of: UPI_failure, card_issue, loan_issue, account_access, fraud_report, internet_banking, branch_service, fd_rd_issue, remittance, other",
  "product": "specific product mentioned e.g. savings account, UPI, home loan",
  "severity": "one of: low, medium, high, critical",
  "sentiment_score": 0.0,
  "sentiment_label": "one of: angry, frustrated, neutral, concerned, satisfied",
  "key_issues": ["issue1", "issue2"]
}}

Rules:
- severity=critical if fraud, money stuck, or very urgent
- severity=high if significant financial impact
- sentiment_score ranges from -1.0 (very angry) to 1.0 (satisfied)
- key_issues: 2-4 short phrases summarizing the problem
- Return ONLY the JSON, no extra text

Complaint: {complaint_text}"""

RESPONSE_PROMPT = """You are a helpful, empathetic customer service agent at Union Bank of India.
Draft a professional response to this complaint.

Category: {category}
Severity: {severity}  
Key issues: {key_issues}
Sentiment: {sentiment_label}
Original complaint: {complaint_text}

Rules:
- Be empathetic and acknowledge the inconvenience
- Reference the specific issue
- Give concrete next steps
- Keep under 120 words
- Do NOT make promises about outcomes
- End with: "Your complaint reference: [REF-{{complaint_id}}]"

Response:"""


async def classify_complaint(text: str) -> dict:
    """Use Claude to classify complaint and extract key info."""
    if not os.getenv("ANTHROPIC_API_KEY"):
        # Return mock data if no API key
        return {
            "category": "UPI_failure",
            "product": "UPI",
            "severity": "high",
            "sentiment_score": -0.7,
            "sentiment_label": "frustrated",
            "key_issues": ["payment failed", "money deducted", "no refund"]
        }

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=500,
            messages=[{
                "role": "user",
                "content": CLASSIFICATION_PROMPT.format(complaint_text=text)
            }]
        )
        raw = response.content[0].text.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()
        return json.loads(raw)
    except Exception as e:
        print(f"Classification error: {e}")
        return {
            "category": "other",
            "product": "unknown",
            "severity": "medium",
            "sentiment_score": -0.3,
            "sentiment_label": "frustrated",
            "key_issues": ["issue reported"]
        }


async def generate_draft_response(complaint_data: dict) -> str:
    """Generate a draft response using Claude."""
    if not os.getenv("ANTHROPIC_API_KEY"):
        return f"Dear Customer, Thank you for contacting Union Bank of India. We have received your complaint regarding {complaint_data.get('category', 'your issue')} and are looking into it. Our team will resolve this within the stipulated time. Your complaint reference: [REF-DEMO]"

    try:
        prompt = RESPONSE_PROMPT.format(
            category=complaint_data.get("category", "general"),
            severity=complaint_data.get("severity", "medium"),
            key_issues=", ".join(complaint_data.get("key_issues", [])),
            sentiment_label=complaint_data.get("sentiment_label", "neutral"),
            complaint_text=complaint_data.get("raw_text", "")
        )
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content[0].text.strip()
    except Exception as e:
        print(f"Response generation error: {e}")
        return "Thank you for contacting Union Bank of India. We have received your complaint and will resolve it at the earliest. Your complaint reference: [REF-PENDING]"


def get_embedding(text: str) -> list:
    """Get sentence embedding for deduplication."""
    if USE_TRANSFORMER:
        embedding = embedder.encode(text, normalize_embeddings=True)
        return embedding.tolist()
    else:
        # Simple fallback: hash-based pseudo-embedding
        import hashlib
        words = text.lower().split()
        vec = [0.0] * 128
        for i, word in enumerate(words[:64]):
            h = int(hashlib.md5(word.encode()).hexdigest(), 16)
            vec[i % 128] += (h % 1000) / 1000.0
        norm = sum(x**2 for x in vec) ** 0.5
        if norm > 0:
            vec = [x / norm for x in vec]
        return vec


def cosine_similarity(a: list, b: list) -> float:
    """Compute cosine similarity between two embeddings."""
    a_arr = np.array(a)
    b_arr = np.array(b)
    if len(a_arr) != len(b_arr):
        min_len = min(len(a_arr), len(b_arr))
        a_arr = a_arr[:min_len]
        b_arr = b_arr[:min_len]
    dot = np.dot(a_arr, b_arr)
    norm_a = np.linalg.norm(a_arr)
    norm_b = np.linalg.norm(b_arr)
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return float(dot / (norm_a * norm_b))
