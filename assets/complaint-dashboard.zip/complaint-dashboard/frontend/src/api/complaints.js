const BASE = 'http://localhost:8000'

export const api = {
  async ingest(payload) {
    const res = await fetch(`${BASE}/complaints/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    if (!res.ok) throw new Error(await res.text())
    return res.json()
  },

  async list({ status, severity, category, slaBreached, channel } = {}) {
    const p = new URLSearchParams()
    if (status)                       p.set('status', status)
    if (severity)                     p.set('severity', severity)
    if (category)                     p.set('category', category)
    if (slaBreached !== undefined)    p.set('sla_breached', slaBreached)
    if (channel)                      p.set('channel', channel)
    p.set('limit', '200')
    const res = await fetch(`${BASE}/complaints/?${p}`)
    return res.json()
  },

  async get(id) {
    const res = await fetch(`${BASE}/complaints/${id}`)
    return res.json()
  },

  async update(id, payload) {
    const res = await fetch(`${BASE}/complaints/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    return res.json()
  },

  async sendResponse(id, text) {
    const res = await fetch(
      `${BASE}/complaints/${id}/send-response?response_text=${encodeURIComponent(text)}`,
      { method: 'POST' }
    )
    return res.json()
  },

  async getTrends(days = 7) {
    const res = await fetch(`${BASE}/analytics/trends?days=${days}`)
    return res.json()
  },

  async getAISummary(days = 7) {
    const res = await fetch(`${BASE}/analytics/ai-summary?days=${days}`)
    return res.json()
  },

  async getRootCause(category) {
    const res = await fetch(`${BASE}/analytics/root-cause/${category}`)
    return res.json()
  },

  async refreshSLA() {
    const res = await fetch(`${BASE}/complaints/refresh-sla`, { method: 'POST' })
    return res.json()
  },
}
