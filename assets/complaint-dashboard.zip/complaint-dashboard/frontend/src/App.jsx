import { useState } from 'react'
import { DashboardPage } from './pages/DashboardPage'
import { AnalyticsPage } from './pages/AnalyticsPage'

export default function App() {
  const [page, setPage] = useState('dashboard')

  const navBtn = (key, label) => (
    <button
      onClick={() => setPage(key)}
      style={{
        padding: '8px 18px',
        background: page === key ? '#534AB7' : 'none',
        color: page === key ? '#fff' : '#555',
        border: 'none',
        borderRadius: '8px',
        fontSize: '14px',
        fontWeight: page === key ? 600 : 400,
        cursor: 'pointer',
      }}
    >
      {label}
    </button>
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: '#f4f3ef' }}>

      {/* Navbar */}
      <nav style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '10px 24px',
        background: '#fff',
        borderBottom: '1px solid #edecea',
        flexShrink: 0,
        zIndex: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '32px', height: '32px', borderRadius: '8px',
            background: '#534AB7', display: 'flex', alignItems: 'center',
            justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: '14px',
          }}>
            UB
          </div>
          <div>
            <p style={{ fontWeight: 700, fontSize: '15px', margin: 0, color: '#1a1a18', lineHeight: 1.2 }}>
              Complaint Dashboard
            </p>
            <p style={{ fontSize: '11px', color: '#aaa', margin: 0 }}>Union Bank of India · Gen-AI Powered</p>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '4px', background: '#f4f3ef', padding: '4px', borderRadius: '10px' }}>
          {navBtn('dashboard', 'Dashboard')}
          {navBtn('analytics', 'Analytics')}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{
            width: '8px', height: '8px', borderRadius: '50%', background: '#1D9E75',
          }} />
          <span style={{ fontSize: '12px', color: '#888' }}>API connected</span>
        </div>
      </nav>

      {/* Page content */}
      <div style={{ flex: 1, overflow: 'hidden' }}>
        {page === 'dashboard' && <DashboardPage />}
        {page === 'analytics' && <AnalyticsPage />}
      </div>
    </div>
  )
}
