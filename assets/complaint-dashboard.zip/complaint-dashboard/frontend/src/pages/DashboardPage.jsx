import { useState, useEffect, useCallback } from 'react'
import { Badge } from '../components/Badge'
import { DetailPanel } from '../components/DetailPanel'
import { SubmitModal } from '../components/SubmitModal'
import { api } from '../api/complaints'
import {
  SEVERITY_COLORS, STATUS_COLORS, SLA_COLORS,
  CHANNEL_ICONS, CATEGORY_LABELS, timeAgo, slaTimeLeft,
} from '../utils'

const FILTERS = [
  { key: 'all',      label: 'All' },
  { key: 'critical', label: 'Critical' },
  { key: 'breached', label: 'SLA Breached' },
  { key: 'dupes',    label: 'Duplicates' },
  { key: 'open',     label: 'Open' },
  { key: 'resolved', label: 'Resolved' },
]

export function DashboardPage() {
  const [complaints, setComplaints] = useState([])
  const [selected, setSelected] = useState(null)
  const [filter, setFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [showSubmit, setShowSubmit] = useState(false)
  const [refreshing, setRefreshing] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = {}
      if (filter === 'critical') params.severity = 'critical'
      else if (filter === 'breached') params.slaBreached = 2
      else if (filter === 'open') params.status = 'open'
      else if (filter === 'resolved') params.status = 'resolved'
      const data = await api.list(params)
      let result = data
      if (filter === 'dupes') result = data.filter(c => c.duplicate_of)
      if (search.trim()) {
        const q = search.toLowerCase()
        result = result.filter(c =>
          c.customer_id.toLowerCase().includes(q) ||
          c.raw_text.toLowerCase().includes(q) ||
          (c.category || '').toLowerCase().includes(q)
        )
      }
      setComplaints(result)
      // Keep selected in sync
      if (selected) {
        const updated = result.find(c => c.id === selected.id)
        if (updated) setSelected(updated)
      }
    } finally {
      setLoading(false)
    }
  }, [filter, search])

  useEffect(() => { load() }, [load])

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(load, 30000)
    return () => clearInterval(interval)
  }, [load])

  async function handleRefreshSLA() {
    setRefreshing(true)
    await api.refreshSLA()
    await load()
    setRefreshing(false)
  }

  function handleUpdated(updated) {
    setSelected(updated)
    setComplaints(prev => prev.map(c => c.id === updated.id ? updated : c))
  }

  function handleSubmitted(newComplaint) {
    setComplaints(prev => [newComplaint, ...prev])
    setSelected(newComplaint)
    setFilter('all')
  }

  // Summary counts
  const counts = {
    total:    complaints.length,
    critical: complaints.filter(c => c.severity === 'critical').length,
    breached: complaints.filter(c => c.sla_breached === 2).length,
    dupes:    complaints.filter(c => c.duplicate_of).length,
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>

      {/* Top bar */}
      <div style={{ padding: '16px 24px', background: '#fff', borderBottom: '1px solid #edecea', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <div style={{ display: 'flex', gap: '16px' }}>
          {[
            { label: 'Total', val: counts.total, color: '#1a1a18' },
            { label: 'Critical', val: counts.critical, color: '#A32D2D' },
            { label: 'SLA Breached', val: counts.breached, color: '#A32D2D' },
            { label: 'Duplicates', val: counts.dupes, color: '#854F0B' },
          ].map(m => (
            <div key={m.label} style={{ textAlign: 'center', minWidth: '60px' }}>
              <p style={{ fontSize: '20px', fontWeight: 700, color: m.color, margin: 0 }}>{m.val}</p>
              <p style={{ fontSize: '11px', color: '#999', margin: 0 }}>{m.label}</p>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button
            onClick={handleRefreshSLA}
            disabled={refreshing}
            style={{ padding: '8px 14px', background: 'none', border: '1px solid #d0cec4', borderRadius: '8px', fontSize: '13px', color: '#555' }}
          >
            {refreshing ? 'Refreshing...' : 'Refresh SLA'}
          </button>
          <button
            onClick={() => setShowSubmit(true)}
            style={{ padding: '8px 18px', background: '#534AB7', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '13px', fontWeight: 500 }}
          >
            + New Complaint
          </button>
        </div>
      </div>

      {/* Main content */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

        {/* Left: complaint list */}
        <div style={{ width: '440px', flexShrink: 0, display: 'flex', flexDirection: 'column', borderRight: '1px solid #edecea', background: '#fff' }}>

          {/* Search */}
          <div style={{ padding: '12px 16px', borderBottom: '1px solid #edecea' }}>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by customer, text or category..."
              style={{ width: '100%', padding: '8px 12px', border: '1px solid #e0deda', borderRadius: '8px', fontSize: '13px', outline: 'none' }}
            />
          </div>

          {/* Filter tabs */}
          <div style={{ display: 'flex', gap: '4px', padding: '10px 12px', borderBottom: '1px solid #edecea', overflowX: 'auto' }}>
            {FILTERS.map(f => (
              <button key={f.key} onClick={() => setFilter(f.key)} style={{
                padding: '5px 12px', borderRadius: '6px', fontSize: '12px', whiteSpace: 'nowrap',
                background: filter === f.key ? '#534AB7' : 'none',
                color: filter === f.key ? '#fff' : '#666',
                border: filter === f.key ? 'none' : '1px solid transparent',
                fontWeight: filter === f.key ? 500 : 400,
              }}>
                {f.label}
              </button>
            ))}
          </div>

          {/* List */}
          <div style={{ flex: 1, overflowY: 'auto' }}>
            {loading ? (
              <p style={{ padding: '24px', color: '#bbb', textAlign: 'center' }}>Loading complaints...</p>
            ) : complaints.length === 0 ? (
              <div style={{ padding: '40px 20px', textAlign: 'center' }}>
                <p style={{ color: '#bbb', fontSize: '14px', marginBottom: '12px' }}>No complaints found.</p>
                <button
                  onClick={() => setShowSubmit(true)}
                  style={{ padding: '8px 16px', background: '#534AB7', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '13px' }}
                >
                  Submit first complaint
                </button>
              </div>
            ) : complaints.map(c => {
              const sev = SEVERITY_COLORS[c.severity] || SEVERITY_COLORS.medium
              const sla = SLA_COLORS[c.sla_breached] || SLA_COLORS[0]
              const isSelected = selected?.id === c.id
              return (
                <div
                  key={c.id}
                  onClick={() => setSelected(c)}
                  style={{
                    padding: '12px 16px',
                    borderBottom: '1px solid #f4f3ef',
                    cursor: 'pointer',
                    background: isSelected ? '#F4F3FF' : '#fff',
                    borderLeft: isSelected ? '3px solid #534AB7' : '3px solid transparent',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '5px' }}>
                    <div style={{ flex: 1, minWidth: 0, marginRight: '8px' }}>
                      <p style={{ fontWeight: 600, fontSize: '13px', marginBottom: '1px', color: '#1a1a18' }}>
                        {CHANNEL_ICONS[c.channel]} {c.customer_id}
                      </p>
                      <p style={{ fontSize: '12px', color: '#666', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {c.raw_text}
                      </p>
                    </div>
                    <p style={{ fontSize: '11px', color: '#aaa', flexShrink: 0 }}>{timeAgo(c.created_at)}</p>
                  </div>
                  <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
                    {c.category && (
                      <Badge bg='#EEEDFE' text='#3C3489'>{CATEGORY_LABELS[c.category] || c.category}</Badge>
                    )}
                    <Badge bg={sev.bg} text={sev.text}>{c.severity}</Badge>
                    <Badge bg={sla.bg} text={sla.text}>{sla.label}</Badge>
                    {c.duplicate_of && <Badge bg='#FAEEDA' text='#633806'>Duplicate</Badge>}
                    {c.sla_deadline && c.sla_breached !== 2 && (
                      <span style={{ fontSize: '11px', color: '#aaa' }}>{slaTimeLeft(c.sla_deadline)}</span>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Right: detail panel */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px', background: '#faf9f7' }}>
          {selected ? (
            <DetailPanel
              key={selected.id}
              complaint={selected}
              onUpdated={handleUpdated}
            />
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#bbb' }}>
              <p style={{ fontSize: '15px', marginBottom: '8px' }}>Select a complaint to view details</p>
              <p style={{ fontSize: '13px' }}>or submit a new one using the button above</p>
            </div>
          )}
        </div>
      </div>

      {showSubmit && (
        <SubmitModal
          onClose={() => setShowSubmit(false)}
          onSubmitted={handleSubmitted}
        />
      )}
    </div>
  )
}
