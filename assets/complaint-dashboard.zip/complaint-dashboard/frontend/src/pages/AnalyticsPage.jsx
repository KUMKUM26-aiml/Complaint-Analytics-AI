import { useState, useEffect } from 'react'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from 'recharts'
import { api } from '../api/complaints'
import { CATEGORY_LABELS } from '../utils'

const COLORS = ['#534AB7', '#1D9E75', '#D85A30', '#BA7517', '#185FA5', '#639922', '#D4537E', '#888780']

export function AnalyticsPage() {
  const [trends, setTrends] = useState(null)
  const [summary, setSummary] = useState('')
  const [rootCause, setRootCause] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [loadingTrends, setLoadingTrends] = useState(true)
  const [loadingSummary, setLoadingSummary] = useState(false)
  const [loadingRC, setLoadingRC] = useState(false)
  const [days, setDays] = useState(7)

  useEffect(() => {
    loadTrends()
  }, [days])

  async function loadTrends() {
    setLoadingTrends(true)
    try {
      const data = await api.getTrends(days)
      setTrends(data)
      if (data.by_category?.length > 0) {
        setSelectedCategory(data.by_category[0].category)
      }
    } finally {
      setLoadingTrends(false)
    }
  }

  async function loadSummary() {
    setLoadingSummary(true)
    try {
      const data = await api.getAISummary(days)
      setSummary(data.summary)
    } finally {
      setLoadingSummary(false)
    }
  }

  async function loadRootCause() {
    if (!selectedCategory) return
    setLoadingRC(true)
    try {
      const data = await api.getRootCause(selectedCategory)
      setRootCause(data.analysis)
    } finally {
      setLoadingRC(false)
    }
  }

  const categoryData = trends?.by_category?.map(d => ({
    name: CATEGORY_LABELS[d.category] || d.category || 'Unknown',
    count: d.count,
  })) || []

  const severityData = trends?.by_severity?.map(d => ({
    name: (d.severity || 'unknown').charAt(0).toUpperCase() + (d.severity || 'unknown').slice(1),
    value: d.count,
  })) || []

  const channelData = trends?.by_channel?.map(d => ({
    name: (d.channel || 'unknown').charAt(0).toUpperCase() + (d.channel || 'unknown').slice(1),
    count: d.count,
  })) || []

  const Card = ({ title, value, sub, color }) => (
    <div style={{ background: '#fff', border: '1px solid #edecea', borderRadius: '12px', padding: '18px 20px' }}>
      <p style={{ fontSize: '12px', color: '#888', marginBottom: '6px' }}>{title}</p>
      <p style={{ fontSize: '26px', fontWeight: 700, color: color || '#1a1a18', margin: '0 0 2px' }}>{value}</p>
      {sub && <p style={{ fontSize: '11px', color: '#aaa' }}>{sub}</p>}
    </div>
  )

  return (
    <div style={{ padding: '28px', maxWidth: '1100px', margin: '0 auto' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '2px' }}>Analytics & Trends</h2>
          <p style={{ fontSize: '13px', color: '#888' }}>Last {days} days · Gen-AI powered insights</p>
        </div>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <span style={{ fontSize: '13px', color: '#666' }}>Period:</span>
          {[7, 14, 30].map(d => (
            <button key={d} onClick={() => setDays(d)} style={{
              padding: '6px 14px', borderRadius: '8px', fontSize: '13px',
              background: days === d ? '#534AB7' : 'none',
              color: days === d ? '#fff' : '#444',
              border: days === d ? 'none' : '1px solid #d0cec4',
            }}>
              {d}d
            </button>
          ))}
        </div>
      </div>

      {loadingTrends ? (
        <p style={{ color: '#888', textAlign: 'center', padding: '40px' }}>Loading analytics...</p>
      ) : (
        <>
          {/* Metric cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '14px', marginBottom: '28px' }}>
            <Card title="Total complaints" value={trends?.total_complaints || 0} />
            <Card title="SLA breaches" value={trends?.sla_breaches || 0} color="#A32D2D" sub="Need attention" />
            <Card title="Duplicates caught" value={trends?.duplicates_caught || 0} color="#854F0B" sub="By AI deduplication" />
            <Card
              title="Avg sentiment"
              value={((trends?.avg_sentiment || 0) > 0 ? '+' : '') + (trends?.avg_sentiment || 0).toFixed(2)}
              color={trends?.avg_sentiment < 0 ? '#A32D2D' : '#27500A'}
              sub="-1 angry → +1 satisfied"
            />
          </div>

          {/* Charts row */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '16px', marginBottom: '24px' }}>

            {/* Category bar chart */}
            <div style={{ background: '#fff', border: '1px solid #edecea', borderRadius: '12px', padding: '20px' }}>
              <p style={{ fontWeight: 600, fontSize: '14px', marginBottom: '16px', color: '#1a1a18' }}>Complaints by category</p>
              {categoryData.length === 0 ? (
                <p style={{ color: '#bbb', textAlign: 'center', padding: '30px 0' }}>No data yet</p>
              ) : (
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={categoryData} layout="vertical" margin={{ left: 10, right: 20 }}>
                    <XAxis type="number" tick={{ fontSize: 11, fill: '#888' }} />
                    <YAxis type="category" dataKey="name" width={120} tick={{ fontSize: 11, fill: '#555' }} />
                    <Tooltip contentStyle={{ fontSize: '12px', borderRadius: '8px', border: '1px solid #edecea' }} />
                    <Bar dataKey="count" fill="#534AB7" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>

            {/* Severity pie chart */}
            <div style={{ background: '#fff', border: '1px solid #edecea', borderRadius: '12px', padding: '20px' }}>
              <p style={{ fontWeight: 600, fontSize: '14px', marginBottom: '16px', color: '#1a1a18' }}>Severity distribution</p>
              {severityData.length === 0 ? (
                <p style={{ color: '#bbb', textAlign: 'center', padding: '30px 0' }}>No data yet</p>
              ) : (
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie data={severityData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name, percent }) => `${name} ${Math.round(percent * 100)}%`} labelLine={false} fontSize={11}>
                      {severityData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ fontSize: '12px', borderRadius: '8px' }} />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Channel bar chart */}
          <div style={{ background: '#fff', border: '1px solid #edecea', borderRadius: '12px', padding: '20px', marginBottom: '24px' }}>
            <p style={{ fontWeight: 600, fontSize: '14px', marginBottom: '16px', color: '#1a1a18' }}>Complaints by channel</p>
            {channelData.length === 0 ? (
              <p style={{ color: '#bbb', textAlign: 'center', padding: '20px 0' }}>No data yet</p>
            ) : (
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={channelData} margin={{ left: 0, right: 20 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#555' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#888' }} />
                  <Tooltip contentStyle={{ fontSize: '12px', borderRadius: '8px', border: '1px solid #edecea' }} />
                  <Bar dataKey="count" fill="#1D9E75" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* AI Summary */}
          <div style={{ background: '#fff', border: '1px solid #edecea', borderRadius: '12px', padding: '20px', marginBottom: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
              <p style={{ fontWeight: 600, fontSize: '14px', color: '#1a1a18' }}>AI Weekly Summary</p>
              <button
                onClick={loadSummary}
                disabled={loadingSummary}
                style={{ padding: '7px 16px', background: '#534AB7', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '13px', fontWeight: 500 }}
              >
                {loadingSummary ? 'Generating...' : 'Generate Summary'}
              </button>
            </div>
            {summary ? (
              <div style={{ background: '#EEEDFE', borderRadius: '8px', padding: '14px', fontSize: '13px', lineHeight: 1.7, color: '#26215C' }}>
                {summary}
              </div>
            ) : (
              <p style={{ color: '#bbb', fontSize: '13px' }}>Click "Generate Summary" to get an AI-powered analysis of complaint trends.</p>
            )}
          </div>

          {/* Root cause analysis */}
          <div style={{ background: '#fff', border: '1px solid #edecea', borderRadius: '12px', padding: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
              <p style={{ fontWeight: 600, fontSize: '14px', color: '#1a1a18' }}>Root Cause Analysis</p>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <select
                  value={selectedCategory}
                  onChange={e => setSelectedCategory(e.target.value)}
                  style={{ padding: '7px 10px', border: '1px solid #d0cec4', borderRadius: '8px', fontSize: '13px', background: '#fff' }}
                >
                  {trends?.by_category?.map(d => (
                    <option key={d.category} value={d.category}>
                      {CATEGORY_LABELS[d.category] || d.category}
                    </option>
                  ))}
                </select>
                <button
                  onClick={loadRootCause}
                  disabled={loadingRC || !selectedCategory}
                  style={{ padding: '7px 16px', background: '#D85A30', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '13px', fontWeight: 500 }}
                >
                  {loadingRC ? 'Analysing...' : 'Analyse'}
                </button>
              </div>
            </div>
            {rootCause ? (
              <div style={{ background: '#FAECE7', borderRadius: '8px', padding: '14px', fontSize: '13px', lineHeight: 1.7, color: '#4A1B0C' }}>
                {rootCause}
              </div>
            ) : (
              <p style={{ color: '#bbb', fontSize: '13px' }}>Select a category and click Analyse to identify root causes.</p>
            )}
          </div>
        </>
      )}
    </div>
  )
}
