import { useState } from 'react'
import { Badge } from './Badge'
import { api } from '../api/complaints'
import {
  SEVERITY_COLORS, STATUS_COLORS, SLA_COLORS,
  CHANNEL_ICONS, CATEGORY_LABELS, formatDate, slaTimeLeft,
} from '../utils'

export function DetailPanel({ complaint, onUpdated }) {
  const [responseText, setResponseText] = useState(complaint.suggested_response || '')
  const [sending, setSending] = useState(false)
  const [sent, setSent] = useState(false)
  const [resolving, setResolving] = useState(false)

  const sev = SEVERITY_COLORS[complaint.severity] || SEVERITY_COLORS.medium
  const stat = STATUS_COLORS[complaint.status] || STATUS_COLORS.open
  const sla = SLA_COLORS[complaint.sla_breached] || SLA_COLORS[0]

  async function handleSendResponse() {
    if (!responseText.trim()) return
    setSending(true)
    try {
      await api.sendResponse(complaint.id, responseText)
      const updated = await api.get(complaint.id)
      onUpdated(updated)
      setSent(true)
      setTimeout(() => setSent(false), 3000)
    } catch (e) {
      console.error(e)
    } finally {
      setSending(false)
    }
  }

  async function handleResolve() {
    setResolving(true)
    try {
      const updated = await api.update(complaint.id, {
        status: 'resolved',
        resolution_note: responseText || 'Resolved by agent.',
      })
      onUpdated(updated)
    } finally {
      setResolving(false)
    }
  }

  async function handleEscalate() {
    const updated = await api.update(complaint.id, { status: 'escalated' })
    onUpdated(updated)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', height: '100%', overflow: 'auto' }}>

      {/* Header */}
      <div style={{ borderBottom: '1px solid #edecea', paddingBottom: '14px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
          <div>
            <p style={{ fontWeight: 600, fontSize: '15px', marginBottom: '2px' }}>{complaint.customer_id}</p>
            <p style={{ fontSize: '12px', color: '#888' }}>
              {CHANNEL_ICONS[complaint.channel]} {complaint.channel} · {formatDate(complaint.created_at)}
            </p>
          </div>
          <Badge bg={stat.bg} text={stat.text}>{complaint.status.replace('_', ' ')}</Badge>
        </div>
        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
          <Badge bg={sev.bg} text={sev.text} border={sev.border}>{complaint.severity}</Badge>
          <Badge bg={sla.bg} text={sla.text}>{sla.label} · {slaTimeLeft(complaint.sla_deadline)}</Badge>
          {complaint.category && (
            <Badge bg='#EEEDFE' text='#3C3489'>{CATEGORY_LABELS[complaint.category] || complaint.category}</Badge>
          )}
          {complaint.duplicate_of && (
            <Badge bg='#FAEEDA' text='#633806'>Duplicate detected</Badge>
          )}
        </div>
      </div>

      {/* Original complaint */}
      <div>
        <p style={{ fontSize: '11px', fontWeight: 600, color: '#888', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '6px' }}>Original Complaint</p>
        <p style={{ fontSize: '13px', lineHeight: 1.65, color: '#333', background: '#f9f8f6', padding: '10px 12px', borderRadius: '8px' }}>
          {complaint.raw_text}
        </p>
      </div>

      {/* AI analysis */}
      {(complaint.key_issues?.length > 0 || complaint.sentiment_label) && (
        <div style={{ background: '#EEEDFE', borderRadius: '10px', padding: '12px 14px' }}>
          <p style={{ fontSize: '11px', fontWeight: 600, color: '#3C3489', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '8px' }}>AI Analysis</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            {complaint.product && (
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                <span style={{ color: '#534AB7' }}>Product</span>
                <span style={{ fontWeight: 500, color: '#26215C' }}>{complaint.product}</span>
              </div>
            )}
            {complaint.sentiment_label && (
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                <span style={{ color: '#534AB7' }}>Sentiment</span>
                <span style={{ fontWeight: 500, color: complaint.sentiment_score < -0.3 ? '#A32D2D' : '#27500A' }}>
                  {complaint.sentiment_label} ({complaint.sentiment_score?.toFixed(2)})
                </span>
              </div>
            )}
            {complaint.key_issues?.length > 0 && (
              <div style={{ fontSize: '12px' }}>
                <span style={{ color: '#534AB7' }}>Key issues</span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginTop: '5px' }}>
                  {complaint.key_issues.map((issue, i) => (
                    <span key={i} style={{ background: '#fff', color: '#3C3489', padding: '2px 8px', borderRadius: '99px', fontSize: '11px', border: '1px solid #AFA9EC' }}>
                      {issue}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Duplicate warning */}
      {complaint.duplicate_of && (
        <div style={{ background: '#FAEEDA', borderRadius: '8px', padding: '10px 12px' }}>
          <p style={{ fontSize: '12px', color: '#633806', fontWeight: 500 }}>
            AI detected this as a duplicate of complaint {complaint.duplicate_of.slice(0, 8)}...
          </p>
          <p style={{ fontSize: '11px', color: '#854F0B', marginTop: '3px' }}>
            Semantic similarity above threshold. Consider merging.
          </p>
        </div>
      )}

      {/* SLA deadline */}
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#666' }}>
        <span>SLA deadline</span>
        <span style={{ color: complaint.sla_breached === 2 ? '#A32D2D' : '#333', fontWeight: 500 }}>
          {formatDate(complaint.sla_deadline)}
        </span>
      </div>

      {/* Communication history */}
      {complaint.communications?.length > 0 && (
        <div>
          <p style={{ fontSize: '11px', fontWeight: 600, color: '#888', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '8px' }}>Communication History</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {complaint.communications.map(comm => (
              <div key={comm.id} style={{
                padding: '8px 10px', borderRadius: '8px', fontSize: '12px',
                background: comm.direction === 'inbound' ? '#f4f3ef' : '#E1F5EE',
                border: `1px solid ${comm.direction === 'inbound' ? '#e0deda' : '#9FE1CB'}`,
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '3px' }}>
                  <span style={{ fontWeight: 500, color: comm.direction === 'inbound' ? '#444' : '#085041' }}>
                    {comm.sent_by === 'customer' ? 'Customer' : 'Agent'} · {comm.channel}
                  </span>
                  <span style={{ color: '#999', fontSize: '11px' }}>{formatDate(comm.created_at)}</span>
                </div>
                <p style={{ color: '#333', lineHeight: 1.5 }}>{comm.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AI Draft response */}
      {complaint.status !== 'resolved' && complaint.status !== 'closed' && (
        <div>
          <p style={{ fontSize: '11px', fontWeight: 600, color: '#888', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '6px' }}>
            AI Draft Response <span style={{ color: '#0F6E56', fontWeight: 400 }}>— Review before sending</span>
          </p>
          <textarea
            value={responseText}
            onChange={e => setResponseText(e.target.value)}
            rows={5}
            style={{ width: '100%', padding: '10px 12px', border: '1px solid #9FE1CB', borderRadius: '8px', fontSize: '12px', lineHeight: 1.6, resize: 'vertical', background: '#E1F5EE', color: '#04342C', outline: 'none' }}
          />
          <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
            <button
              onClick={handleSendResponse}
              disabled={sending || sent}
              style={{ flex: 1, padding: '9px', background: sent ? '#1D9E75' : '#0F6E56', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '13px', fontWeight: 500 }}
            >
              {sent ? 'Sent!' : sending ? 'Sending...' : 'Send Response'}
            </button>
            <button
              onClick={handleResolve}
              disabled={resolving}
              style={{ flex: 1, padding: '9px', background: 'none', border: '1px solid #1D9E75', color: '#0F6E56', borderRadius: '8px', fontSize: '13px', fontWeight: 500 }}
            >
              {resolving ? '...' : 'Mark Resolved'}
            </button>
            <button
              onClick={handleEscalate}
              style={{ padding: '9px 14px', background: 'none', border: '1px solid #F09595', color: '#A32D2D', borderRadius: '8px', fontSize: '13px' }}
            >
              Escalate
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
