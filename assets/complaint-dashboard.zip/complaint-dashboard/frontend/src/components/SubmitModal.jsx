import { useState } from 'react'
import { api } from '../api/complaints'

const CHANNELS = ['app', 'email', 'phone', 'branch', 'social', 'rbi']

export function SubmitModal({ onClose, onSubmitted }) {
  const [form, setForm] = useState({ customer_id: '', channel: 'app', raw_text: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit() {
    if (!form.customer_id.trim() || !form.raw_text.trim()) {
      setError('Customer ID and complaint text are required.')
      return
    }
    setLoading(true)
    setError('')
    try {
      const result = await api.ingest(form)
      onSubmitted(result)
      onClose()
    } catch (e) {
      setError('Failed to submit. Make sure the backend is running.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100,
    }}>
      <div style={{
        background: '#fff', borderRadius: '14px', padding: '28px',
        width: '100%', maxWidth: '500px', boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2 style={{ fontSize: '17px', fontWeight: 600, color: '#1a1a18' }}>Submit New Complaint</h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: '20px', color: '#888', lineHeight: 1 }}>×</button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div>
            <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '5px' }}>Customer ID *</label>
            <input
              value={form.customer_id}
              onChange={e => setForm(f => ({ ...f, customer_id: e.target.value }))}
              placeholder="e.g. CUST-001"
              style={{ width: '100%', padding: '9px 12px', border: '1px solid #e0deda', borderRadius: '8px', fontSize: '14px', outline: 'none' }}
            />
          </div>

          <div>
            <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '5px' }}>Channel *</label>
            <select
              value={form.channel}
              onChange={e => setForm(f => ({ ...f, channel: e.target.value }))}
              style={{ width: '100%', padding: '9px 12px', border: '1px solid #e0deda', borderRadius: '8px', fontSize: '14px', background: '#fff', outline: 'none' }}
            >
              {CHANNELS.map(c => (
                <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>
              ))}
            </select>
          </div>

          <div>
            <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '5px' }}>Complaint Text * (Hindi or English)</label>
            <textarea
              value={form.raw_text}
              onChange={e => setForm(f => ({ ...f, raw_text: e.target.value }))}
              placeholder="Describe the complaint in detail..."
              rows={5}
              style={{ width: '100%', padding: '9px 12px', border: '1px solid #e0deda', borderRadius: '8px', fontSize: '14px', resize: 'vertical', outline: 'none' }}
            />
          </div>

          {error && <p style={{ color: '#A32D2D', fontSize: '13px', background: '#FCEBEB', padding: '8px 12px', borderRadius: '6px' }}>{error}</p>}

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '4px' }}>
            <button onClick={onClose} style={{ padding: '9px 18px', background: 'none', border: '1px solid #d0cec4', borderRadius: '8px', fontSize: '14px', color: '#555' }}>
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={loading}
              style={{ padding: '9px 20px', background: loading ? '#a09ad4' : '#534AB7', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '14px', fontWeight: 500 }}
            >
              {loading ? 'Processing AI...' : 'Submit Complaint'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
