export function Badge({ children, bg, text, border }) {
  return (
    <span style={{
      display: 'inline-block',
      padding: '2px 9px',
      borderRadius: '99px',
      fontSize: '11px',
      fontWeight: 500,
      background: bg || '#F1EFE8',
      color: text || '#5F5E5A',
      border: `1px solid ${border || 'transparent'}`,
      whiteSpace: 'nowrap',
    }}>
      {children}
    </span>
  )
}
