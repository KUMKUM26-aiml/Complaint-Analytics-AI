export const SEVERITY_COLORS = {
  critical: { bg: '#FCEBEB', text: '#A32D2D', border: '#F09595' },
  high:     { bg: '#FAEEDA', text: '#633806', border: '#FAC775' },
  medium:   { bg: '#E6F1FB', text: '#0C447C', border: '#85B7EB' },
  low:      { bg: '#EAF3DE', text: '#27500A', border: '#97C459' },
}

export const STATUS_COLORS = {
  open:        { bg: '#E6F1FB', text: '#0C447C' },
  in_progress: { bg: '#FAEEDA', text: '#633806' },
  escalated:   { bg: '#FCEBEB', text: '#A32D2D' },
  resolved:    { bg: '#EAF3DE', text: '#27500A' },
  closed:      { bg: '#F1EFE8', text: '#5F5E5A' },
}

export const SLA_COLORS = {
  0: { bg: '#EAF3DE', text: '#27500A', label: 'On time' },
  1: { bg: '#FAEEDA', text: '#633806', label: 'Warning' },
  2: { bg: '#FCEBEB', text: '#A32D2D', label: 'Breached' },
}

export const CHANNEL_ICONS = {
  branch:  '🏦',
  phone:   '📞',
  email:   '✉️',
  app:     '📱',
  social:  '💬',
  rbi:     '⚖️',
}

export const CATEGORY_LABELS = {
  UPI_failure:      'UPI Failure',
  card_issue:       'Card Issue',
  loan_issue:       'Loan Issue',
  account_access:   'Account Access',
  fraud_report:     'Fraud Report',
  internet_banking: 'Internet Banking',
  branch_service:   'Branch Service',
  fd_rd_issue:      'FD / RD Issue',
  remittance:       'Remittance',
  other:            'Other',
}

export function formatDate(dateStr) {
  if (!dateStr) return '—'
  const d = new Date(dateStr)
  return d.toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  })
}

export function timeAgo(dateStr) {
  if (!dateStr) return ''
  const diff = Date.now() - new Date(dateStr).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  return `${Math.floor(hrs / 24)}d ago`
}

export function slaTimeLeft(deadline) {
  if (!deadline) return ''
  const diff = new Date(deadline).getTime() - Date.now()
  if (diff <= 0) return 'Overdue'
  const hrs = Math.floor(diff / 3600000)
  const mins = Math.floor((diff % 3600000) / 60000)
  if (hrs > 24) return `${Math.floor(hrs / 24)}d left`
  if (hrs > 0) return `${hrs}h ${mins}m left`
  return `${mins}m left`
}
